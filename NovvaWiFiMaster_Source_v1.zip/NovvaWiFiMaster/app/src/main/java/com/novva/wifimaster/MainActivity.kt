package com.novva.wifimaster

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiManager
import android.net.wifi.WifiNetworkSpecifier
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter

class MainActivity : Activity() {
    private lateinit var wifiManager: WifiManager
    private lateinit var listArea: LinearLayout
    private lateinit var statusText: TextView
    private var receiverRegistered = false
    private var connectionCallback: ConnectivityManager.NetworkCallback? = null

    private val scanReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == WifiManager.SCAN_RESULTS_AVAILABLE_ACTION) {
                showScanResults()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        buildScreen()
        registerScanReceiver()
        showSavedNotice()
    }

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 20)
            setBackgroundColor(Color.rgb(246, 248, 252))
        }

        val title = TextView(this).apply {
            text = "NOVVA"
            textSize = 30f
            setTextColor(Color.rgb(15, 39, 76))
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        page.addView(title)

        val subtitle = TextView(this).apply {
            text = "WiFi Master  •  Discover. Connect. Share."
            textSize = 14f
            setTextColor(Color.rgb(85, 101, 122))
            setPadding(0, 2, 0, 18)
        }
        page.addView(subtitle)

        statusText = TextView(this).apply {
            text = "Ready to discover nearby networks."
            textSize = 14f
            setTextColor(Color.rgb(30, 57, 91))
            setPadding(14, 14, 14, 14)
            setBackgroundColor(Color.rgb(229, 237, 248))
        }
        page.addView(statusText)

        val scanButton = Button(this).apply {
            text = "SCAN FOR WI-FI NETWORKS"
            setOnClickListener { beginScan() }
        }
        page.addView(scanButton, matchWrap())

        val qrButton = Button(this).apply {
            text = "CREATE A WI-FI QR CODE"
            setOnClickListener { showQrInputDialog() }
        }
        page.addView(qrButton, matchWrap())

        val heading = TextView(this).apply {
            text = "Nearby networks"
            textSize = 20f
            setTextColor(Color.rgb(15, 39, 76))
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 18, 0, 8)
        }
        page.addView(heading)

        val scroll = ScrollView(this)
        listArea = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(listArea)
        page.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        val footer = TextView(this).apply {
            text = "Only connect to networks you are allowed to use. Android controls the final connection approval."
            textSize = 12f
            setTextColor(Color.DKGRAY)
            setPadding(0, 12, 0, 0)
        }
        page.addView(footer)
        setContentView(page)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun showSavedNotice() {
        statusText.text = "Tap Scan to discover nearby Wi-Fi. Location permission is required by Android for scan results."
    }

    private fun registerScanReceiver() {
        val filter = IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(scanReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(scanReceiver, filter)
        }
        receiverRegistered = true
    }

    private fun beginScan() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 100)
            return
        }
        if (!wifiManager.isWifiEnabled) {
            statusText.text = "Please turn on Wi-Fi, then scan again."
            startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
            return
        }
        try {
            statusText.text = "Scanning… Android may limit how often apps can request scans."
            @Suppress("DEPRECATION")
            val started = wifiManager.startScan()
            if (!started) {
                statusText.text = "A new scan could not start. Showing the latest results available."
                showScanResults()
            }
        } catch (e: SecurityException) {
            statusText.text = "Permission is missing. Please allow location access while using the app."
        } catch (e: Exception) {
            statusText.text = "Scan unavailable: ${e.localizedMessage ?: "try again"}"
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            beginScan()
        } else {
            statusText.text = "Location permission was not granted, so Android did not provide Wi-Fi scan results."
        }
    }

    @Suppress("DEPRECATION")
    private fun showScanResults() {
        try {
            val results = wifiManager.scanResults
                .filter { it.SSID.isNotBlank() }
                .distinctBy { it.BSSID }
                .sortedByDescending { it.level }

            listArea.removeAllViews()
            if (results.isEmpty()) {
                statusText.text = "No networks returned. Check Wi-Fi and Location, then try again later."
                return
            }
            statusText.text = "Found ${results.size} visible network(s). Signal results may be cached by Android."
            results.forEach { result ->
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(16, 12, 16, 12)
                    setBackgroundColor(Color.WHITE)
                    val params = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                    )
                    params.setMargins(0, 5, 0, 5)
                    layoutParams = params
                }
                val name = TextView(this).apply {
                    text = result.SSID
                    textSize = 17f
                    setTextColor(Color.rgb(15, 39, 76))
                    setTypeface(null, android.graphics.Typeface.BOLD)
                }
                val details = TextView(this).apply {
                    val level = WifiManager.calculateSignalLevel(result.level, 5)
                    val security = when {
                        result.capabilities.contains("WPA3") -> "WPA3"
                        result.capabilities.contains("WPA2") -> "WPA2"
                        result.capabilities.contains("WPA") -> "WPA/WPA2"
                        result.capabilities.contains("WEP") -> "WEP"
                        else -> "Open / other"
                    }
                    text = "Signal: ${level}/4  •  ${result.level} dBm  •  $security"
                    textSize = 13f
                    setTextColor(Color.DKGRAY)
                }
                card.addView(name)
                card.addView(details)
                card.setOnClickListener { askToConnect(result.SSID, result.capabilities) }
                listArea.addView(card)
            }
        } catch (e: SecurityException) {
            statusText.text = "Android blocked scan results. Check app permission and Location setting."
        }
    }

    private fun askToConnect(ssid: String, capabilities: String) {
        val input = EditText(this).apply {
            hint = "Network password (leave blank if open)"
            if (capabilities.contains("WPA") || capabilities.contains("WEP")) {
                inputType = android.text.InputType.TYPE_CLASS_TEXT or
                    android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            }
        }
        AlertDialog.Builder(this)
            .setTitle("Connect to $ssid")
            .setMessage("Enter the password only if you are authorized to use this network. Android will ask you to approve the connection.")
            .setView(input)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Continue") { _, _ ->
                connectWithAndroidApproval(ssid, input.text.toString(), capabilities)
            }
            .show()
    }

    private fun connectWithAndroidApproval(ssid: String, password: String, capabilities: String) {
        if (Build.VERSION.SDK_INT < 29) {
            statusText.text = "For this Android version, use Settings > Wi-Fi to connect. QR sharing is available below."
            startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
            return
        }
        if ((capabilities.contains("WPA") || capabilities.contains("WEP")) && password.isBlank()) {
            Toast.makeText(this, "Enter the network password.", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val specifierBuilder = WifiNetworkSpecifier.Builder().setSsid(ssid)
            if (capabilities.contains("WPA")) {
                specifierBuilder.setWpa2Passphrase(password)
            } else if (capabilities.contains("WEP")) {
                Toast.makeText(this, "This network's security type is not supported by this connection flow.", Toast.LENGTH_LONG).show()
                return
            }
            val request = NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .setNetworkSpecifier(specifierBuilder.build())
                .build()

            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            connectionCallback?.let { try { cm.unregisterNetworkCallback(it) } catch (_: Exception) {} }
            val callback = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    runOnUiThread {
                        statusText.text = "Android approved the Wi-Fi connection request for $ssid."
                        Toast.makeText(this@MainActivity, "Connection request accepted.", Toast.LENGTH_SHORT).show()
                    }
                }
                override fun onUnavailable() {
                    runOnUiThread {
                        statusText.text = "Connection was not completed. Check the password or try again."
                    }
                }
            }
            connectionCallback = callback
            cm.requestNetwork(request, callback)
            statusText.text = "Waiting for Android's Wi-Fi approval prompt…"
        } catch (e: Exception) {
            statusText.text = "Could not request connection: ${e.localizedMessage ?: "try again"}"
        }
    }

    private fun showQrInputDialog() {
        val fields = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 8, 24, 0)
        }
        val ssid = EditText(this).apply { hint = "Wi-Fi network name (SSID)" }
        val password = EditText(this).apply {
            hint = "Password (leave blank for open network)"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        fields.addView(ssid, matchWrap())
        fields.addView(password, matchWrap())

        AlertDialog.Builder(this)
            .setTitle("Create Wi-Fi QR code")
            .setMessage("Create a shareable code only for a network whose credentials you are allowed to share.")
            .setView(fields)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Create") { _, _ ->
                val networkName = ssid.text.toString()
                val pass = password.text.toString()
                if (networkName.isBlank()) {
                    Toast.makeText(this, "Enter the Wi-Fi name.", Toast.LENGTH_SHORT).show()
                } else {
                    displayQr(networkName, pass)
                }
            }
            .show()
    }

    private fun displayQr(ssid: String, password: String) {
        try {
            fun escapeWifi(value: String) = value
                .replace("\\", "\\\\")
                .replace(";", "\\;")
                .replace(",", "\\,")
                .replace(":", "\\:")
                .replace("\"", "\\\"")
            val type = if (password.isBlank()) "nopass" else "WPA"
            val payload = "WIFI:T:$type;S:${escapeWifi(ssid)};P:${escapeWifi(password)};;"
            val matrix = QRCodeWriter().encode(payload, BarcodeFormat.QR_CODE, 700, 700)
            val bitmap = Bitmap.createBitmap(700, 700, Bitmap.Config.RGB_565)
            for (x in 0 until 700) {
                for (y in 0 until 700) {
                    bitmap.setPixel(x, y, if (matrix[x, y]) Color.BLACK else Color.WHITE)
                }
            }
            val image = ImageView(this).apply {
                setImageBitmap(bitmap)
                adjustViewBounds = true
                setPadding(24, 24, 24, 24)
            }
            AlertDialog.Builder(this)
                .setTitle("Wi-Fi QR code")
                .setMessage("Anyone who scans this code may be able to join this Wi-Fi network. Share it carefully.")
                .setView(image)
                .setPositiveButton("Done", null)
                .show()
        } catch (e: Exception) {
            Toast.makeText(this, "Could not create QR code: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        if (receiverRegistered) {
            try { unregisterReceiver(scanReceiver) } catch (_: Exception) {}
        }
        super.onDestroy()
    }
}
