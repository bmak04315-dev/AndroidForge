# Novva WiFi Master — Android source

Version 1.0 starter project for AndroidForge.

## Features
- Lists visible Wi-Fi networks returned by Android's Wi-Fi scan API.
- Shows approximate signal level and security information.
- Requests a connection using Android's user-approved Wi-Fi network request interface on Android 10+.
- Creates a standard Wi-Fi QR code from credentials the user enters and is authorized to share.

## Important Android limitations
- Android requires location permission and Location services enabled for Wi-Fi scan results on many Android versions.
- Android throttles scan requests; results can be cached or unavailable.
- The app does not reveal passwords from nearby protected networks.
- Android displays its own approval prompt for connection requests.
- On Android versions below 10, use system Wi-Fi settings to connect.

## Build
Open this project with Android Studio, or upload this ZIP to your AndroidForge repository and run the **Build Android APK** workflow.
