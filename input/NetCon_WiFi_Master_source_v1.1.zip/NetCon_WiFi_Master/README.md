# NetCon WiFi Master — Android source

Native Kotlin + Jetpack Compose app. App branding is **NetCon WiFi Master** only; no “Powered by ETHIONOVVA” label is included.

## Features
- Nearby Wi-Fi scan: SSID, signal (dBm), frequency band/channel and advertised security capabilities.
- Passive security review flags open/no-encryption, WEP, legacy WPA and WPA2/TKIP advertisements.
- Wi-Fi QR scanner; decodes SSID/security/password only if those details are encoded in the scanned QR.
- Wi-Fi QR generator for networks you own or are authorized to share.
- Android-approved connection request on Android 10+; Android displays its own approval UI.
- Shortcut to Android Wi-Fi settings.

## Platform boundaries
This app does not crack passwords, brute-force routers, exploit router vulnerabilities, bypass Wi-Fi encryption, or extract passwords from nearby networks. A normal Android app cannot silently connect to arbitrary networks or read every saved Wi-Fi password.

For your own saved network: Android Settings > Wi-Fi > your connected network > Share; authenticate when prompted, then scan the displayed QR with this app. Device makers may place this option in a different menu.

Wi-Fi scanning may require Location permission and the Location setting to be enabled. Android may throttle scan frequency. The passive audit reads advertised scan capabilities only; it is not a penetration test and cannot prove a router is secure.

## Router hardening
Prefer WPA3-Personal, or WPA2-Personal with AES/CCMP only. Disable WEP, legacy WPA, TKIP and WPS PIN. Change the router administrator password, use a long unique Wi-Fi passphrase, update firmware, disable unused remote administration, and use a guest network for visitors/IoT.

## Build
The project root contains `settings.gradle.kts` and `app/`. Upload this ZIP to AndroidForge's source input and run its Build Android APK workflow. Internet access is required during build for Gradle dependencies.
Package: `com.netcon.wifimaster` — version 1.1.0 (versionCode 3).
