# NetCon WiFi Master 1.2.0

A Kotlin + Jetpack Compose Android Wi-Fi utility.

## Features
- Requests nearby Wi-Fi scans and displays SSID, signal strength (dBm), and band/channel where available.
- Shows a passive assessment of advertised Wi-Fi security (WPA2/WPA3, legacy WPA, WEP, or open).
- Estimates the strength of a password entered by the user. It cannot discover or measure a router's actual password from a Wi-Fi broadcast.
- Scans standard Wi-Fi QR codes. It can display SSID/password only when those credentials are encoded in the QR code.
- Lets the user request a connection using a selected network or decoded QR credentials.
- Generates a Wi-Fi QR code for a network the user owns or is authorized to share.
- Includes router hardening recommendations.

## Important Android limitations
Android does not allow ordinary third-party apps to force-connect silently to arbitrary nearby Wi-Fi networks, bypass a password, or extract passwords from nearby routers. For protected networks, the user must provide valid credentials and approve Android's system connection prompt. QR scanning reveals credentials only if the QR code contains them. Android may throttle Wi-Fi scans or restrict results based on OS version, permissions, and device settings.

## Build
Java 17, Android Gradle Plugin 8.7.3, Gradle 8.9, compileSdk 35.
