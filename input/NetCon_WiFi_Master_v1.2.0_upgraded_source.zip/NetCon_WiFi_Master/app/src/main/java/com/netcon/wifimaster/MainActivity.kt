package com.netcon.wifimaster

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.ScanResult
import android.net.wifi.WifiManager
import android.net.wifi.WifiNetworkSpecifier
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Color as UiColor
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.google.android.gms.code.scanner.GmsBarcodeScanning
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import java.util.Locale

private val Navy = UiColor(0xFF102A56)
private val Blue = UiColor(0xFF4A90E2)
private val Pale = UiColor(0xFFEAF3FF)

data class WifiQr(val ssid: String, val password: String, val security: String)
data class SecurityAssessment(val label: String, val risk: String, val advice: String)

class MainActivity : ComponentActivity() {
    private lateinit var wifi: WifiManager
    private var connectionCallback: ConnectivityManager.NetworkCallback? = null

    private val permissions = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (it.values.any { ok -> ok }) scanWifi()
        else status.value = "Permission denied. Allow Location and Nearby Wi-Fi to scan."
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            @Suppress("DEPRECATION")
            val results = try { wifi.scanResults.sortedByDescending { it.level } } catch (_: Exception) { emptyList() }
            networks.value = results
            status.value = if (results.isEmpty()) "No results. Enable Wi-Fi and Location, then scan again."
                else "Found ${results.size} visible network(s). Review only networks you own or are authorized to test."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        try { registerReceiver(receiver, IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION)) } catch (_: Exception) {}
        setContent {
            NetConApp(
                scan = { requestScanPermissions() },
                connect = { s, p -> requestConnection(s, p) },
                scanQr = { scanQr() },
                openSettings = { startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) }
            )
        }
    }

    override fun onDestroy() {
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        try { connectionCallback?.let { getSystemService(ConnectivityManager::class.java).unregisterNetworkCallback(it) } } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun requestScanPermissions() {
        val needed = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) needed.add(Manifest.permission.NEARBY_WIFI_DEVICES)
        val missing = needed.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) scanWifi() else permissions.launch(missing.toTypedArray())
    }

    @Suppress("DEPRECATION")
    private fun scanWifi() {
        if (!wifi.isWifiEnabled) {
            status.value = "Wi-Fi is off. Turn it on and scan again."
            startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
            return
        }
        try {
            val started = wifi.startScan()
            networks.value = wifi.scanResults.sortedByDescending { it.level }
            status.value = if (started) "Scan requested. Android may throttle scans; results refresh when available."
                else "Android throttled this scan. Showing the latest available results."
        } catch (_: SecurityException) {
            status.value = "Permission denied. Grant scan permissions and enable Location in phone settings."
        } catch (e: Exception) { status.value = "Scan error: ${e.localizedMessage ?: "unavailable"}" }
    }

    private fun requestConnection(ssid: String, password: String) {
        if (Build.VERSION.SDK_INT < 29) {
            status.value = "Use Android Wi-Fi settings to connect on this Android version."
            startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
            return
        }
        if (ssid.isBlank()) { status.value = "Enter a network name first."; return }
        try {
            val spec = WifiNetworkSpecifier.Builder().setSsid(ssid)
                .apply { if (password.isNotEmpty()) setWpa2Passphrase(password) }.build()
            val request = NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .setNetworkSpecifier(spec).build()
            val cm = getSystemService(ConnectivityManager::class.java)
            connectionCallback?.let { try { cm.unregisterNetworkCallback(it) } catch (_: Exception) {} }
            val cb = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) { status.value = "Android approved the connection request for $ssid." }
                override fun onUnavailable() { status.value = "Connection was declined or the network was unavailable." }
                override fun onLost(network: Network) { status.value = "The requested Wi-Fi connection was lost." }
            }
            connectionCallback = cb
            cm.requestNetwork(request, cb)
            status.value = "Android will show its own approval prompt. No silent connection is attempted."
        } catch (e: Exception) { status.value = "Connection request failed: ${e.localizedMessage ?: "unknown error"}" }
    }

    private fun scanQr() {
        try {
            GmsBarcodeScanning.getClient(this).startScan()
                .addOnSuccessListener { barcode ->
                    val raw = barcode.rawValue ?: return@addOnSuccessListener
                    val decoded = parseWifiQr(raw)
                    qrValue.value = decoded
                    status.value = if (decoded != null) "Wi-Fi QR decoded. Password is shown only if it was encoded in the QR."
                        else "QR scanned, but it is not a standard Wi-Fi QR code."
                    if (decoded == null) otherQr.value = raw
                }
                .addOnCanceledListener { status.value = "QR scan cancelled." }
                .addOnFailureListener { status.value = "QR scanner failed. Check Google Play services." }
        } catch (e: Exception) { status.value = "QR scanner unavailable: ${e.localizedMessage ?: "unknown error"}" }
    }

    companion object {
        val networks = mutableStateOf<List<ScanResult>>(emptyList())
        val status = mutableStateOf("Discover nearby Wi-Fi, review advertised security, or decode a Wi-Fi QR.")
        val qrValue = mutableStateOf<WifiQr?>(null)
        val otherQr = mutableStateOf<String?>(null)
    }
}

fun parseWifiQr(raw: String): WifiQr? {
    if (!raw.startsWith("WIFI:", true)) return null
    val body = raw.substringAfter("WIFI:")
    fun field(key: String): String {
        val m = Regex("(?:^|;)$key:((?:\\\\.|[^;])*)").find(body) ?: return ""
        return m.groupValues[1].replace("\\\\;", ";").replace("\\\\:", ":")
            .replace("\\\\,", ",").replace("\\\\\\\\", "\\\\")
    }
    return WifiQr(field("S"), field("P"), field("T").ifBlank { "nopass" })
}

fun assess(caps: String): SecurityAssessment {
    val c = caps.uppercase(Locale.ROOT)
    return when {
        "WEP" in c -> SecurityAssessment("WEP", "CRITICAL", "WEP is obsolete. Replace it with WPA2-AES/CCMP or WPA3.")
        "WPA3" in c -> SecurityAssessment("WPA3", "LOWER RISK", "Modern protection is advertised. Use a strong unique passphrase.")
        "WPA2" in c && "TKIP" in c -> SecurityAssessment("WPA2 mixed / TKIP", "NEEDS REVIEW", "Disable TKIP and use AES/CCMP only, or WPA3.")
        "WPA2" in c -> SecurityAssessment("WPA2", "GOOD BASELINE", "Prefer AES/CCMP and a long unique passphrase.")
        "WPA" in c -> SecurityAssessment("Legacy WPA", "NEEDS REVIEW", "Replace legacy WPA with WPA2-AES or WPA3.")
        else -> SecurityAssessment("Open / no encryption advertised", "HIGH RISK", "Enable WPA2-AES/CCMP or WPA3 on your router.")
    }
}
fun signal(dbm: Int) = when { dbm >= -55 -> "Excellent"; dbm >= -67 -> "Good"; dbm >= -75 -> "Fair"; else -> "Weak" }

fun passwordStrength(password: String): Pair<String, String> {
    if (password.isEmpty()) return "Not checked" to "Enter a password to estimate its strength."
    var score = 0
    if (password.length >= 8) score++
    if (password.length >= 12) score++
    if (password.any { it.isLowerCase() } && password.any { it.isUpperCase() }) score++
    if (password.any { it.isDigit() }) score++
    if (password.any { !it.isLetterOrDigit() }) score++
    return when {
        password.length < 8 || score <= 1 -> "Weak" to "Use at least 12 characters with mixed character types."
        score <= 3 -> "Moderate" to "A longer, unique passphrase would be safer."
        else -> "Strong" to "Good estimate. Avoid reusing this password."
    }
}
fun band(freq: Int) = when {
    freq in 2412..2472 -> "2.4 GHz • ch ${(freq - 2407) / 5}"
    freq == 2484 -> "2.4 GHz • ch 14"
    freq in 5000..5900 -> "5 GHz band"
    freq in 5925..7125 -> "6 GHz band"
    else -> "Band unavailable"
}
fun esc(s: String) = s.replace("\\\\", "\\\\\\\\").replace(";", "\\\\;").replace(",", "\\\\,").replace(":", "\\\\:")
fun qrBitmap(text: String): Bitmap {
    val matrix = MultiFormatWriter().encode(text, BarcodeFormat.QR_CODE, 600, 600)
    return Bitmap.createBitmap(600, 600, Bitmap.Config.ARGB_8888).also { bmp ->
        for (x in 0 until 600) for (y in 0 until 600) bmp.setPixel(x, y, if (matrix[x, y]) Color.BLACK else Color.WHITE)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NetConApp(scan: () -> Unit, connect: (String, String) -> Unit, scanQr: () -> Unit, openSettings: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    var ssid by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var qrImage by remember { mutableStateOf<Bitmap?>(null) }
    var showConnectDialog by remember { mutableStateOf(false) }
    var connectSecurity by remember { mutableStateOf("WPA2/WPA3") }
    val strength = passwordStrength(password)
    val list by MainActivity.networks
    val message by MainActivity.status
    val decoded by MainActivity.qrValue

    MaterialTheme(colorScheme = lightColorScheme(primary = Navy, secondary = Blue)) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Column {
                        Text("NetCon WiFi Master", fontWeight = FontWeight.Bold)
                        Text("Discover • Analyze • Share", style = MaterialTheme.typography.labelSmall)
                    } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = UiColor.White)
                )
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(tab == 0, { tab = 0 }, icon = { Icon(Icons.Default.Wifi, null) }, label = { Text("Networks") })
                    NavigationBarItem(tab == 1, { tab = 1 }, icon = { Icon(Icons.Default.Security, null) }, label = { Text("Audit") })
                    NavigationBarItem(tab == 2, { tab = 2 }, icon = { Icon(Icons.Default.QrCodeScanner, null) }, label = { Text("QR Tools") })
                }
            },
            containerColor = UiColor(0xFFF6F9FE)
        ) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).padding(14.dp)) {
                Card(colors = CardDefaults.cardColors(containerColor = Pale), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(13.dp)) {
                        Text("NETCON STATUS", color = Navy, fontWeight = FontWeight.Bold)
                        Text(message, color = Navy)
                    }
                }
                Spacer(Modifier.height(10.dp))
                when (tab) {
                    0 -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Nearby Wi-Fi", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Button(onClick = scan) { Icon(Icons.Default.Refresh, null); Text(" Scan") }
                        }
                        Text("Android may limit scan frequency and may hide some networks.", style = MaterialTheme.typography.bodySmall)
                        LazyColumn(Modifier.weight(1f, fill = false), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            items(list) { item ->
                                val a = assess(item.capabilities)
                                Card {
                                    Column(Modifier.padding(11.dp)) {
                                        Text(item.SSID.ifBlank { "(Hidden SSID)" }, fontWeight = FontWeight.Bold)
                                        Text("${item.level} dBm • ${signal(item.level)} • ${band(item.frequency)}")
                                        Text("${a.label} • ${a.risk}")
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            TextButton(onClick = { ssid = item.SSID; tab = 1 }) { Text("Security details") }
                                            Button(onClick = { ssid = item.SSID; connectSecurity = item.capabilities; showConnectDialog = true }) { Text("Connect") }
                                        }
                                    }
                                }
                            }
                        }
                        OutlinedTextField(ssid, { ssid = it }, label = { Text("Network name (SSID)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(password, { password = it }, label = { Text("Network password (if required)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        Text("Password estimate: ${strength.first} — ${strength.second}", style = MaterialTheme.typography.bodySmall)
                        Button(onClick = { connect(ssid, password) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Wifi, null); Text(" Request Android connection") }
                        TextButton(onClick = openSettings, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("Open Android Wi-Fi settings") }
                    }
                    1 -> {
                        Text("Router security review", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("Passive review of security capabilities broadcast by access points. This is not a penetration test.")
                        Spacer(Modifier.height(8.dp))
                        if (list.isEmpty()) Text("Scan first to see advertised security settings.")
                        else LazyColumn(Modifier.weight(1f, fill = false), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            items(list) { item ->
                                val a = assess(item.capabilities)
                                Card {
                                    Column(Modifier.padding(12.dp)) {
                                        Text(item.SSID.ifBlank { "(Hidden SSID)" }, fontWeight = FontWeight.Bold)
                                        Text("${a.label} • ${a.risk}", fontWeight = FontWeight.SemiBold)
                                        Text(a.advice)
                                        Text("Broadcast: ${item.capabilities}", style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                        }
                        Card(colors = CardDefaults.cardColors(containerColor = Pale)) {
                            Column(Modifier.padding(12.dp)) {
                                Text("Router hardening checklist", color = Navy, fontWeight = FontWeight.Bold)
                                Text("• Prefer WPA3-Personal; otherwise WPA2-AES/CCMP.")
                                Text("• Disable WEP, legacy WPA, TKIP and WPS PIN.")
                                Text("• Change the router administrator password.")
                                Text("• Use a long, unique Wi-Fi passphrase.")
                                Text("• Update firmware; disable unused remote administration.")
                                Text("• Create a guest network for visitors and IoT devices.")
                            }
                        }
                    }
                    else -> {
                        Text("Wi-Fi QR tools", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Button(onClick = scanQr, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.QrCodeScanner, null); Text(" Scan Wi-Fi QR") }
                        decoded?.let { q ->
                            Card(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(12.dp)) {
                                    Text("Decoded Wi-Fi QR", fontWeight = FontWeight.Bold)
                                    Text("SSID: ${q.ssid}")
                                    Text("Security: ${q.security}")
                                    Text("Password: ${q.password.ifBlank { "(not encoded)" }}")
                                    Text("Credentials come only from the scanned QR content.")
                                    Spacer(Modifier.height(8.dp))
                                    Button(onClick = { ssid = q.ssid; password = q.password; connect(q.ssid, q.password) }, enabled = q.ssid.isNotBlank()) {
                                        Icon(Icons.Default.Wifi, null); Text(" Request connection using QR")
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        Text("Create QR for your own network", fontWeight = FontWeight.Bold)
                        OutlinedTextField(ssid, { ssid = it }, label = { Text("Wi-Fi name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(password, { password = it }, label = { Text("Wi-Fi password") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        Button(onClick = {
                            if (ssid.isNotBlank()) qrImage = qrBitmap("WIFI:T:${if (password.isBlank()) "nopass" else "WPA"};S:${esc(ssid)};P:${esc(password)};;")
                        }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.QrCode, null); Text(" Generate QR") }
                        qrImage?.let { Image(it.asImageBitmap(), "Generated Wi-Fi QR", Modifier.fillMaxWidth().height(210.dp)) }
                    }
                }
            }
        }
        if (showConnectDialog) {
            AlertDialog(
                onDismissRequest = { showConnectDialog = false },
                title = { Text("Connect to $ssid") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Choose a network you own or are authorized to use. Android will display its own approval prompt.")
                        if (connectSecurity.contains("WEP", true) || connectSecurity.contains("WPA", true) ||
                            connectSecurity.contains("PSK", true) || connectSecurity.contains("SAE", true)) {
                            OutlinedTextField(
                                value = password,
                                onValueChange = { password = it },
                                label = { Text("Wi-Fi password") },
                                singleLine = true
                            )
                            val scoreNow = passwordStrength(password)
                            Text("Password estimate: ${scoreNow.first}. ${scoreNow.second}")
                        } else {
                            Text("This network appears to be open. Open networks are not encrypted.")
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        showConnectDialog = false
                        connect(ssid, password)
                    }) { Text("Continue") }
                },
                dismissButton = {
                    TextButton(onClick = { showConnectDialog = false }) { Text("Cancel") }
                }
            )
        }
    }
}
