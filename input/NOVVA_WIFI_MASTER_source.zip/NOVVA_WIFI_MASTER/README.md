# NOVVA WIFI MASTER — Android source project

ETHIONOVVA TECHNOLOGY

## Features in this starter build
- Nearby Wi-Fi scan using Android Wi-Fi APIs (permission and Android location-toggle requirements apply).
- Signal strength display and basic signal labels.
- Wi-Fi network suggestions for a supplied SSID/password on Android 10+; Android controls app approval and connection timing.
- QR scanning through Google Play services Code Scanner.
- Decode standard Wi-Fi QR payloads and display the SSID/password encoded in that QR.
- Generate Wi-Fi QR codes for networks the user owns or is authorized to share.

## Important Android limitations
- This app does not crack, guess, bypass, or extract passwords from nearby networks.
- Android does not allow ordinary apps to silently connect to arbitrary networks or reveal every saved Wi-Fi password.
- Android controls approval of Wi-Fi suggestions and decides when a suggested network is selected; this app cannot force a silent connection.
- To recover a saved network's shareable QR/password, use Android's built-in Wi-Fi Share flow (device unlock/biometric approval); then scan that QR with this app.
- Some manufacturers restrict Wi-Fi scanning or require Location to be enabled even after permission is granted.

## Build with AndroidForge
Upload this ZIP as the Android source ZIP. Project root contains `settings.gradle.kts` and `app/`.
Select Android, build variant `debug` or `auto`, and run Build Android APK.
This project requires internet access during build to resolve Maven/Gradle dependencies.

## Package
`com.ethionovva.wifimaster`
