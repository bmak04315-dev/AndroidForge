package com.ethionovva.wifimaster

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.wifi.ScanResult
import android.net.wifi.WifiManager
import android.net.wifi.WifiNetworkSuggestion
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.graphics.Bitmap
import android.graphics.Color
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Color as ComposeColor
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.google.android.gms.mlkit.codescanner.GmsBarcodeScanning
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import java.util.Locale

private val Navy = ComposeColor(0xFF102A56)
private val Blue = ComposeColor(0xFF4A90E2)
private val Pale = ComposeColor(0xFFEAF3FF)

class MainActivity : ComponentActivity() {
    private lateinit var wifi: WifiManager
    private val scanPermission = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { scanWifi() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        setContent { NovvaApp(
            onScan = { requestScan() },
            onConnect = { ssid, password -> connectToNetwork(ssid, password) },
            onQrScan = { scanQr() }
        ) }
    }

    private fun requestScan() {
        val needed = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) needed.add(Manifest.permission.NEARBY_WIFI_DEVICES)
        val missing = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) scanPermission.launch(missing.toTypedArray()) else scanWifi()
    }

    @Suppress("DEPRECATION")
    private fun scanWifi() {
        if (!wifi.isWifiEnabled) {
            startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
            return
        }
        try {
            wifi.startScan()
            val list = wifi.scanResults.sortedByDescending { it.level }
            runOnUiThread { scanResults.value = list }
        } catch (_: SecurityException) {
            runOnUiThread { appMessage.value = "Allow location and nearby Wi-Fi permission to scan." }
        } catch (_: Exception) {
            runOnUiThread { appMessage.value = "Wi-Fi scan is unavailable on this device right now." }
        }
    }

    private fun connectToNetwork(ssid: String, password: String) {
        if (Build.VERSION.SDK_INT < 29) {
            startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
            appMessage.value = "On this Android version, add the network in Android Wi-Fi settings."
            return
        }
        try {
            val builder = WifiNetworkSuggestion.Builder().setSsid(ssid)
            if (password.isNotBlank()) builder.setWpa2Passphrase(password)
            val suggestion = builder.build()
            val status = wifi.addNetworkSuggestions(listOf(suggestion))
            appMessage.value = when (status) {
                WifiManager.STATUS_NETWORK_SUGGESTIONS_SUCCESS ->
                    "Network suggestion submitted. Android controls approval and when it connects."
                WifiManager.STATUS_NETWORK_SUGGESTIONS_ERROR_ADD_DUPLICATE ->
                    "This network suggestion is already registered with Android. Check Wi-Fi settings."
                else -> "Android did not accept the network suggestion (status $status)."
            }
        } catch (e: Exception) {
            appMessage.value = "Could not submit network suggestion: ${e.localizedMessage ?: "unknown error"}"
        }
    }

    private fun scanQr() {
        try {
            GmsBarcodeScanning.getClient(this).startScan()
                .addOnSuccessListener { barcode ->
                    val raw = barcode.rawValue ?: return@addOnSuccessListener
                    val parsed = parseWifiQr(raw)
                    appMessage.value = if (parsed != null) {
                        qrDetails.value = parsed
                        "Wi-Fi QR decoded. Review the network details below."
                    } else "QR content: $raw"
                }
                .addOnFailureListener { appMessage.value = "QR scanner could not start. Check Google Play services." }
        } catch (_: Exception) {
            appMessage.value = "QR scanner is not available on this device."
        }
    }

    companion object {
        val scanResults = mutableStateOf<List<ScanResult>>(emptyList())
        val appMessage = mutableStateOf("Welcome. Scan nearby networks or use a Wi-Fi QR code.")
        val qrDetails = mutableStateOf<WifiQr?>(null)
    }
}

data class WifiQr(val ssid: String, val password: String, val security: String)

fun parseWifiQr(raw: String): WifiQr? {
    if (!raw.startsWith("WIFI:", true)) return null
    fun field(key: String): String {
        val match = Regex("(?:^|;)$key:((?:\\\\.|[^;])*)").find(raw.removePrefix("WIFI:")) ?: return ""
        return match.groupValues[1].replace("\\\\;", ";").replace("\\\\:", ":").replace("\\\\\\\\", "\\\\")
    }
    return WifiQr(field("S"), field("P"), field("T").ifBlank { "nopass" })
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NovvaApp(
    onScan: () -> Unit,
    onConnect: (String, String) -> Unit,
    onQrScan: () -> Unit
) {
    var tab by remember { mutableStateOf(0) }
    var ssid by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var generated by remember { mutableStateOf<Bitmap?>(null) }
    val networks by MainActivity.scanResults
    val message by MainActivity.appMessage
    val qr by MainActivity.qrDetails

    MaterialTheme(colorScheme = lightColorScheme(primary = Navy, secondary = Blue)) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("NOVVA WIFI MASTER", fontWeight = FontWeight.Bold)
                            Text("ETHIONOVVA TECHNOLOGY", style = MaterialTheme.typography.labelSmall)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = ComposeColor.White)
                )
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Wifi, null) }, label = { Text("Networks") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.QrCodeScanner, null) }, label = { Text("QR Scan") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.QrCode, null) }, label = { Text("QR Create") })
                }
            },
            containerColor = ComposeColor(0xFFF6F9FE)
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                Card(colors = CardDefaults.cardColors(containerColor = Pale), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("READ  •  REVIEW  •  CONNECT", color = Navy, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text(message, color = Navy)
                    }
                }
                Spacer(Modifier.height(14.dp))
                when (tab) {
                    0 -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Nearby Wi-Fi", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Button(onClick = onScan) { Icon(Icons.Default.Refresh, null); Text(" Scan") }
                        }
                        Text("Signal readings are provided by Android. Scan results may be restricted by device settings.", style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(8.dp))
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(networks) { item ->
                                Card {
                                    Column(Modifier.fillMaxWidth().padding(12.dp)) {
                                        Text(item.SSID.ifBlank { "(Hidden network)" }, fontWeight = FontWeight.Bold)
                                        Text("Signal: ${item.level} dBm  •  ${signalLabel(item.level)}")
                                        Text("Security: ${item.capabilities.take(45)}", style = MaterialTheme.typography.bodySmall)
                                        TextButton(onClick = { ssid = item.SSID; password = "" }) { Text("Use this network") }
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(value = ssid, onValueChange = { ssid = it }, label = { Text("Network name (SSID)") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("Password (only if you know or are authorized to use it)") }, modifier = Modifier.fillMaxWidth())
                        Button(onClick = { if (ssid.isNotBlank()) onConnect(ssid, password) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Wifi, null); Text(" Request connection") }
                    }
                    1 -> {
                        Text("Scan a Wi-Fi QR code", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("The scanner reads QR codes you point the camera at. It does not discover or reveal passwords from nearby routers.")
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = onQrScan, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.QrCodeScanner, null); Text(" Open QR scanner") }
                        qr?.let {
                            Card(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(14.dp)) {
                                    Text("Decoded Wi-Fi details", fontWeight = FontWeight.Bold)
                                    Text("SSID: ${it.ssid}")
                                    Text("Security: ${it.security}")
                                    Text("Password: ${if (it.password.isBlank()) "(none in QR)" else it.password}")
                                    Text("Only use these credentials for a network you are authorized to access.", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                    else -> {
                        Text("Create a Wi-Fi QR code", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("Generate a shareable QR code for a network you own or are authorized to share.")
                        OutlinedTextField(value = ssid, onValueChange = { ssid = it }, label = { Text("Network name (SSID)") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("Wi-Fi password") }, modifier = Modifier.fillMaxWidth())
                        Button(onClick = {
                            if (ssid.isNotBlank()) generated = makeQr("WIFI:T:WPA;S:${escapeWifi(ssid)};P:${escapeWifi(password)};;")
                        }, modifier = Modifier.fillMaxWidth()) { Text("Generate QR") }
                        generated?.let { Image(it.asImageBitmap(), "Wi-Fi QR code", Modifier.fillMaxWidth().height(230.dp)) }
                    }
                }
            }
        }
    }
}

fun signalLabel(level: Int) = when {
    level >= -55 -> "Excellent"
    level >= -67 -> "Good"
    level >= -75 -> "Fair"
    else -> "Weak"
}
fun escapeWifi(s: String) = s.replace("\\\\", "\\\\\\\\").replace(";", "\\\\;").replace(",", "\\\\,").replace(":", "\\\\:")
fun makeQr(content: String): Bitmap {
    val matrix = MultiFormatWriter().encode(content, BarcodeFormat.QR_CODE, 640, 640)
    val bmp = Bitmap.createBitmap(640, 640, Bitmap.Config.ARGB_8888)
    for (x in 0 until 640) for (y in 0 until 640) bmp.setPixel(x, y, if (matrix[x, y]) Color.BLACK else Color.WHITE)
    return bmp
}
