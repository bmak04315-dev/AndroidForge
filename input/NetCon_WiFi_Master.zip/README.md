# NetCon WiFi Master 1.3.0

Native Android application built with Kotlin and Jetpack Compose.

## Features
- Scan nearby Wi-Fi access points and display SSID, signal strength, frequency/band, channel and advertised security.
- Review advertised security using a passive checklist. This is not a penetration test and cannot prove a router is secure.
- Request a connection to a network using Android's system approval dialog. Android controls the final connection; some devices/networks may require using Android Wi-Fi Settings instead.
- Scan standard `WIFI:` QR codes. SSID/password can only be read if the QR code actually contains those values.
- Generate a Wi-Fi QR code for a network you own or are authorized to share.
- Estimate the strength of a password entered by the user. This is a local heuristic, not a test of the router's actual password.
- Shortcut to Android Wi-Fi settings.

## Important Android limitations
- Android may throttle Wi-Fi scans. Scan results can require Location permission and the Location setting to be enabled, depending on Android version and device.
- Android 10+ requires user/system approval for app-requested Wi-Fi connections. This app cannot silently join arbitrary networks.
- The app cannot reveal passwords from nearby networks, crack passwords, bypass encryption, or access networks without authorization.
- WPA/WEP legacy networks may need to be joined through Android Wi-Fi Settings rather than the app's connection request.

## Build information
- Package: `com.netcon.wifimaster`
- Version: `1.3.0` (versionCode 5)
- Minimum SDK: 26
- Compile/Target SDK: 35
- Java: 17
- Android Gradle Plugin: 8.7.3
- Kotlin: 2.0.21

## AndroidForge ZIP layout
This archive intentionally places `settings.gradle.kts`, `build.gradle.kts`, and `app/` directly at the ZIP root. Do not wrap these files in an additional parent directory before uploading to AndroidForge's `input/` folder.
