package com.netcon.wifimaster

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.ScanResult
import android.net.wifi.WifiManager
import android.net.wifi.WifiNetworkSpecifier
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.google.android.gms.code.scanner.GmsBarcodeScanning
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import android.graphics.Bitmap
import android.graphics.Color as AndroidColor
import java.util.Locale

private val Navy = Color(0xFF102A56)
private val Blue = Color(0xFF4A90E2)
private val Background = Color(0xFFF4F7FC)
private val PaleBlue = Color(0xFFEAF2FF)
private val Ink = Color(0xFF17243A)
private val Muted = Color(0xFF66758B)
private val Green = Color(0xFF16865B)
private val Amber = Color(0xFFB7791F)
private val Red = Color(0xFFB42318)

data class WifiQr(val ssid: String, val password: String, val security: String)
data class SecurityAssessment(val label: String, val level: String, val advice: String)

class MainActivity : ComponentActivity() {
    private lateinit var wifi: WifiManager
    private var connectionCallback: ConnectivityManager.NetworkCallback? = null

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
            if (grants[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                scanWifi()
            } else {
                appStatus.value = "Location permission is needed by Android to show nearby Wi-Fi scan results."
            }
        }

    private val scanReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            @Suppress("DEPRECATION")
            val found = try { wifi.scanResults.sortedByDescending { it.level } } catch (_: Exception) { emptyList() }
            networks.value = found
            appStatus.value = if (found.isEmpty()) {
                "No networks returned. Check Wi-Fi and Location, then scan again."
            } else {
                "Found ${found.size} visible network(s). Only connect to networks you are authorized to use."
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val filter = IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(scanReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(scanReceiver, filter)
        }

        setContent {
            NetConTheme {
                NetConScreen(
                    scan = { requestScanPermissions() },
                    connect = { name, pass, security -> requestConnection(name, pass, security) },
                    scanQr = { scanWifiQr() },
                    openSettings = { startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) }
                )
            }
        }
    }

    override fun onDestroy() {
        try { unregisterReceiver(scanReceiver) } catch (_: Exception) {}
        try {
            connectionCallback?.let {
                getSystemService(ConnectivityManager::class.java).unregisterNetworkCallback(it)
            }
        } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun requestScanPermissions() {
        val required = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) required.add(Manifest.permission.NEARBY_WIFI_DEVICES)
        val missing = required.distinct().filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) scanWifi() else permissionLauncher.launch(missing.toTypedArray())
    }

    @Suppress("DEPRECATION")
    private fun scanWifi() {
        if (!wifi.isWifiEnabled) {
            appStatus.value = "Wi-Fi is turned off. Turn it on, then scan again."
            startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
            return
        }
        try {
            val started = wifi.startScan()
            networks.value = wifi.scanResults.sortedByDescending { it.level }
            appStatus.value = if (started) {
                "Scanning nearby networks… Android may limit how often apps can scan."
            } else {
                "Android limited this scan. Showing the latest results available."
            }
        } catch (_: SecurityException) {
            appStatus.value = "Permission denied. Allow the requested Wi-Fi scan permissions."
        } catch (e: Exception) {
            appStatus.value = "Scan unavailable: ${e.localizedMessage ?: "unknown error"}"
        }
    }

    private fun requestConnection(ssid: String, password: String, security: String) {
        if (Build.VERSION.SDK_INT < 29) {
            appStatus.value = "Use Android Wi-Fi Settings to connect on this Android version."
            startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
            return
        }
        if (ssid.isBlank()) {
            appStatus.value = "Choose or enter a network name first."
            return
        }
        val caps = security.uppercase(Locale.ROOT)
        if ("WEP" in caps || (("WPA" in caps) && "WPA2" !in caps && "WPA3" !in caps)) {
            appStatus.value = "This legacy security type is not supported by the in-app request. Use Android Wi-Fi Settings."
            startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
            return
        }
        if (password.isNotEmpty() && password.length < 8) {
            appStatus.value = "A WPA/WPA2/WPA3 passphrase is usually at least 8 characters."
            return
        }
        try {
            val builder = WifiNetworkSpecifier.Builder().setSsid(ssid)
            when {
                password.isBlank() -> Unit
                "WPA3" in caps -> builder.setWpa3Passphrase(password)
                else -> builder.setWpa2Passphrase(password)
            }
            val specifier = builder.build()
            val request = NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .setNetworkSpecifier(specifier)
                .build()
            val cm = getSystemService(ConnectivityManager::class.java)
            connectionCallback?.let { old -> try { cm.unregisterNetworkCallback(old) } catch (_: Exception) {} }
            val callback = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    appStatus.value = "Android approved the Wi-Fi request for “$ssid”. Availability is managed by Android."
                }
                override fun onUnavailable() {
                    appStatus.value = "The request was declined, timed out, or the network could not be joined."
                }
                override fun onLost(network: Network) {
                    appStatus.value = "The requested Wi-Fi network is no longer available."
                }
            }
            connectionCallback = callback
            cm.requestNetwork(request, callback)
            appStatus.value = "Approve the connection in Android's system prompt. This app cannot connect silently."
        } catch (e: IllegalArgumentException) {
            appStatus.value = "Check the network password and security type, or use Android Wi-Fi Settings."
        } catch (e: Exception) {
            appStatus.value = "Connection request failed: ${e.localizedMessage ?: "unknown error"}"
        }
    }

    private fun scanWifiQr() {
        try {
            GmsBarcodeScanning.getClient(this).startScan()
                .addOnSuccessListener { barcode ->
                    val raw = barcode.rawValue.orEmpty()
                    val parsed = parseWifiQr(raw)
                    qrResult.value = parsed
                    appStatus.value = if (parsed != null) {
                        "Wi-Fi QR decoded. Credentials are available only if they were stored in the QR."
                    } else {
                        "QR scanned, but it is not a standard Wi-Fi sharing code."
                    }
                    if (parsed == null) otherQr.value = raw
                }
                .addOnCanceledListener { appStatus.value = "QR scan cancelled." }
                .addOnFailureListener {
                    appStatus.value = "QR scanner unavailable. Check Google Play services and try again."
                }
        } catch (e: Exception) {
            appStatus.value = "Could not start QR scanner: ${e.localizedMessage ?: "unknown error"}"
        }
    }

    companion object {
        val networks = mutableStateOf<List<ScanResult>>(emptyList())
        val appStatus = mutableStateOf("Scan nearby Wi-Fi, review advertised security, or scan a Wi-Fi QR.")
        val qrResult = mutableStateOf<WifiQr?>(null)
        val otherQr = mutableStateOf<String?>(null)
    }
}

@Composable
private fun NetConTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Navy,
            onPrimary = Color.White,
            secondary = Blue,
            background = Background,
            surface = Color.White,
            onSurface = Ink
        ),
        typography = Typography(),
        content = content
    )
}

fun parseWifiQr(raw: String): WifiQr? {
    if (!raw.startsWith("WIFI:", ignoreCase = true)) return null
    val body = raw.substringAfter("WIFI:")
    fun readField(key: String): String {
        val match = Regex("(?:^|;)$key:((?:\\\\.|[^;])*)").find(body) ?: return ""
        return match.groupValues[1]
            .replace("\\;", ";")
            .replace("\\:", ":")
            .replace("\\,", ",")
            .replace("\\\\", "\\")
    }
    return WifiQr(
        ssid = readField("S"),
        password = readField("P"),
        security = readField("T").ifBlank { "nopass" }
    ).takeIf { it.ssid.isNotBlank() }
}

fun assessSecurity(capabilities: String): SecurityAssessment {
    val value = capabilities.uppercase(Locale.ROOT)
    return when {
        "WEP" in value -> SecurityAssessment("WEP", "Critical", "WEP is obsolete. Replace it with WPA2-AES/CCMP or WPA3.")
        "WPA3" in value -> SecurityAssessment("WPA3 advertised", "Modern", "A strong, unique passphrase is still important. This scan cannot verify router configuration.")
        "WPA2" in value && "TKIP" in value -> SecurityAssessment("WPA2 / TKIP", "Review", "Disable TKIP and prefer AES/CCMP, or use WPA3.")
        "WPA2" in value -> SecurityAssessment("WPA2 advertised", "Good baseline", "Prefer AES/CCMP and a long, unique passphrase.")
        "WPA" in value -> SecurityAssessment("Legacy WPA", "Review", "Replace legacy WPA with WPA2-AES/CCMP or WPA3.")
        else -> SecurityAssessment("Open / unknown", "High risk", "If this is your router, enable WPA2-AES/CCMP or WPA3.")
    }
}

fun signalLabel(dbm: Int): String = when {
    dbm >= -55 -> "Excellent"
    dbm >= -67 -> "Good"
    dbm >= -75 -> "Fair"
    else -> "Weak"
}

fun frequencyLabel(mhz: Int): String {
    val channel = when {
        mhz in 2412..2472 -> "Channel ${(mhz - 2407) / 5}"
        mhz == 2484 -> "Channel 14"
        mhz in 5000..5900 -> "5 GHz"
        mhz in 5925..7125 -> "6 GHz"
        else -> "Channel unavailable"
    }
    val band = when {
        mhz in 2400..2500 -> "2.4 GHz"
        mhz in 5000..5900 -> "5 GHz"
        mhz in 5925..7125 -> "6 GHz"
        else -> "Band unavailable"
    }
    return if (band == "Band unavailable") band else "$band • $channel"
}

fun passwordRating(password: String): Pair<String, Int> {
    if (password.isEmpty()) return "Not entered" to 0
    var score = 0
    if (password.length >= 8) score++
    if (password.length >= 12) score++
    if (password.length >= 16) score++
    if (password.any(Char::isLowerCase) && password.any(Char::isUpperCase)) score++
    if (password.any(Char::isDigit)) score++
    if (password.any { !it.isLetterOrDigit() }) score++
    val label = when {
        password.length < 8 -> "Too short"
        score <= 2 -> "Weak"
        score <= 4 -> "Fair"
        else -> "Strong"
    }
    return label to score
}

private fun escapeWifiField(value: String): String = value
    .replace("\\", "\\\\")
    .replace(";", "\\;")
    .replace(",", "\\,")
    .replace(":", "\\:")

private fun createWifiQr(ssid: String, password: String): String {
    val type = if (password.isBlank()) "nopass" else "WPA"
    return "WIFI:T:$type;S:${escapeWifiField(ssid)};P:${escapeWifiField(password)};;"
}

private fun makeQrBitmap(content: String): Bitmap {
    val matrix = MultiFormatWriter().encode(content, BarcodeFormat.QR_CODE, 640, 640)
    return Bitmap.createBitmap(640, 640, Bitmap.Config.ARGB_8888).also { bitmap ->
        for (x in 0 until 640) for (y in 0 until 640) {
            bitmap.setPixel(x, y, if (matrix[x, y]) AndroidColor.BLACK else AndroidColor.WHITE)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NetConScreen(
    scan: () -> Unit,
    connect: (String, String, String) -> Unit,
    scanQr: () -> Unit,
    openSettings: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var selectedNetwork by remember { mutableStateOf<ScanResult?>(null) }
    var networkName by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }
    var generatedQr by remember { mutableStateOf<Bitmap?>(null) }

    val foundNetworks by MainActivity.networks
    val status by MainActivity.appStatus
    val scannedQr by MainActivity.qrResult
    val passwordScore = passwordRating(password)

    Scaffold(
        containerColor = Background,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(
                            Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(Navy),
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Filled.Wifi, contentDescription = null, tint = Color.White) }
                        Column {
                            Text("NetCon", fontWeight = FontWeight.ExtraBold, color = Navy)
                            Text("WIFI MASTER", style = MaterialTheme.typography.labelSmall, color = Muted, fontWeight = FontWeight.Bold)
                        }
                    }
                },
                actions = {
                    IconButton(onClick = openSettings) {
                        Icon(Icons.Filled.Settings, contentDescription = "Wi-Fi settings", tint = Navy)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Filled.Wifi, contentDescription = null) },
                    label = { Text("Discover") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Filled.Shield, contentDescription = null) },
                    label = { Text("Security") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Filled.QrCode2, contentDescription = null) },
                    label = { Text("QR tools") }
                )
            }
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            StatusCard(status)
            when (selectedTab) {
                0 -> DiscoverTab(
                    networks = foundNetworks,
                    onScan = scan,
                    onConnect = { selectedNetwork = it; networkName = it.SSID; password = "" }
                )
                1 -> SecurityTab(networks = foundNetworks, password = password, onPasswordChange = { password = it })
                else -> QrTab(
                    scannedQr = scannedQr,
                    generatedQr = generatedQr,
                    networkName = networkName,
                    password = password,
                    onNetworkNameChange = { networkName = it },
                    onPasswordChange = { password = it },
                    onScanQr = scanQr,
                    onGenerate = {
                        if (networkName.isNotBlank()) generatedQr = makeQrBitmap(createWifiQr(networkName, password))
                    },
                    onConnectScanned = { q ->
                        connect(q.ssid, q.password, q.security)
                    }
                )
            }
        }
    }

    selectedNetwork?.let { item ->
        val security = item.capabilities
        AlertDialog(
            onDismissRequest = { selectedNetwork = null },
            title = { Text("Connect to network", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(item.SSID.ifBlank { "Hidden network" }, color = Navy, fontWeight = FontWeight.SemiBold)
                    Text("Enter credentials only for a network you own or are authorized to use.")
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("Wi-Fi password") },
                        singleLine = true,
                        visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { showPassword = !showPassword }) {
                                Icon(if (showPassword) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, contentDescription = "Toggle password visibility")
                            }
                        }
                    )
                    val strength = passwordRating(password)
                    Text("Password estimate: ${strength.first}", color = when (strength.first) {
                        "Strong" -> Green
                        "Fair" -> Amber
                        "Weak", "Too short" -> Red
                        else -> Muted
                    }, fontWeight = FontWeight.SemiBold)
                }
            },
            confirmButton = {
                Button(onClick = {
                    connect(item.SSID, password, security)
                    selectedNetwork = null
                }) { Text("Continue") }
            },
            dismissButton = {
                TextButton(onClick = { selectedNetwork = null }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun StatusCard(status: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Navy),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                Modifier.size(42.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.Wifi, contentDescription = null, tint = Color.White) }
            Column(Modifier.weight(1f)) {
                Text("NETWORK STATUS", color = Color(0xFFBFD8FF), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                Text(status, color = Color.White, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun DiscoverTab(
    networks: List<ScanResult>,
    onScan: () -> Unit,
    onConnect: (ScanResult) -> Unit
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("Nearby networks", style = MaterialTheme.typography.titleLarge, color = Navy, fontWeight = FontWeight.ExtraBold)
            Text("${networks.size} network(s) visible", color = Muted, style = MaterialTheme.typography.bodySmall)
        }
        Button(onClick = onScan, shape = RoundedCornerShape(14.dp)) {
            Icon(Icons.Filled.Refresh, contentDescription = null)
            Spacer(Modifier.width(6.dp))
            Text("Scan")
        }
    }
    if (networks.isEmpty()) {
        EmptyState(
            icon = Icons.Filled.Wifi,
            title = "Ready to discover",
            description = "Turn on Wi-Fi, allow scan permission, then tap Scan to list nearby access points.",
            action = onScan
        )
    } else {
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 12.dp)
        ) {
            items(networks, key = { "${it.BSSID}_${it.frequency}" }) { item ->
                NetworkCard(item = item, onConnect = { onConnect(item) })
            }
        }
    }
    Text(
        "Scan results are provided by Android and may be throttled. Hidden network names may not be shown.",
        color = Muted,
        style = MaterialTheme.typography.labelSmall
    )
}

@Composable
private fun NetworkCard(item: ScanResult, onConnect: () -> Unit) {
    val security = assessSecurity(item.capabilities)
    val strength = signalLabel(item.level)
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(PaleBlue),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Filled.Wifi, contentDescription = null, tint = Navy) }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(item.SSID.ifBlank { "Hidden network" }, color = Ink, fontWeight = FontWeight.Bold)
                    Text("${item.level} dBm • $strength", color = Muted, style = MaterialTheme.typography.bodySmall)
                }
                SecurityPill(security.level)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
                InfoChip(frequencyLabel(item.frequency))
                InfoChip(security.label)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Signal", color = Muted, style = MaterialTheme.typography.labelSmall)
                Spacer(Modifier.width(8.dp))
                LinearProgressIndicator(
                    progress = { ((item.level + 100).coerceIn(0, 70) / 70f) },
                    modifier = Modifier.weight(1f).height(6.dp).clip(CircleShape),
                    color = Blue,
                    trackColor = PaleBlue
                )
                Spacer(Modifier.width(8.dp))
                Text(strength, color = Navy, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold)
            }
            Button(
                onClick = onConnect,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(vertical = 10.dp)
            ) {
                Icon(Icons.Filled.Link, contentDescription = null)
                Spacer(Modifier.width(7.dp))
                Text("Connect")
            }
        }
    }
}

@Composable
private fun SecurityPill(level: String) {
    val tint = when (level) {
        "Modern", "Good baseline" -> Green
        "Critical", "High risk" -> Red
        else -> Amber
    }
    Surface(color = tint.copy(alpha = 0.10f), shape = RoundedCornerShape(30.dp)) {
        Text(level.uppercase(), color = tint, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp))
    }
}

@Composable
private fun InfoChip(text: String) {
    Surface(color = PaleBlue, shape = RoundedCornerShape(8.dp)) {
        Text(text, color = Navy, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp))
    }
}

@Composable
private fun SecurityTab(networks: List<ScanResult>, password: String, onPasswordChange: (String) -> Unit) {
    Text("Security overview", style = MaterialTheme.typography.titleLarge, color = Navy, fontWeight = FontWeight.ExtraBold)
    Text("A passive review of advertised Wi-Fi security. It is not a penetration test.", color = Muted, style = MaterialTheme.typography.bodySmall)
    PasswordStrengthCard(password, onPasswordChange)
    if (networks.isEmpty()) {
        EmptyState(Icons.Filled.Shield, "No scan data yet", "Go to Discover and scan nearby networks to review their advertised security.")
    } else {
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            items(networks, key = { "audit_${it.BSSID}_${it.frequency}" }) { item ->
                val result = assessSecurity(item.capabilities)
                Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(item.SSID.ifBlank { "Hidden network" }, modifier = Modifier.weight(1f), color = Ink, fontWeight = FontWeight.Bold)
                            SecurityPill(result.level)
                        }
                        Text(result.label, color = Navy, fontWeight = FontWeight.SemiBold)
                        Text(result.advice, color = Muted, style = MaterialTheme.typography.bodySmall)
                        Text("Advertised capabilities: ${item.capabilities.ifBlank { "Not reported" }}", color = Muted, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
    Card(colors = CardDefaults.cardColors(containerColor = PaleBlue), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text("Router hardening checklist", color = Navy, fontWeight = FontWeight.Bold)
            Text("• Prefer WPA3-Personal, or WPA2-AES/CCMP.")
            Text("• Disable WEP, legacy WPA, TKIP and WPS PIN.")
            Text("• Change the router admin password and update firmware.")
            Text("• Use a long, unique Wi-Fi passphrase.")
        }
    }
}

@Composable
private fun PasswordStrengthCard(password: String, onPasswordChange: (String) -> Unit) {
    val (label, score) = passwordRating(password)
    val color = when (label) {
        "Strong" -> Green
        "Fair" -> Amber
        "Weak", "Too short" -> Red
        else -> Muted
    }
    Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text("Password strength estimate", color = Navy, fontWeight = FontWeight.Bold)
            Text("Enter a password you control. It is evaluated locally and is not sent anywhere.", color = Muted, style = MaterialTheme.typography.bodySmall)
            OutlinedTextField(
                value = password,
                onValueChange = onPasswordChange,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Test a password") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(label, color = color, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                Text(if (password.isBlank()) " " else "$score / 6", color = Muted, style = MaterialTheme.typography.labelSmall)
            }
            LinearProgressIndicator(
                progress = { if (password.isBlank()) 0f else (score / 6f).coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape),
                color = color,
                trackColor = PaleBlue
            )
        }
    }
}

@Composable
private fun QrTab(
    scannedQr: WifiQr?,
    generatedQr: Bitmap?,
    networkName: String,
    password: String,
    onNetworkNameChange: (String) -> Unit,
    onPasswordChange: (String) -> Unit,
    onScanQr: () -> Unit,
    onGenerate: () -> Unit,
    onConnectScanned: (WifiQr) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 14.dp)
    ) {
        item {
            Text("Wi-Fi QR tools", style = MaterialTheme.typography.titleLarge, color = Navy, fontWeight = FontWeight.ExtraBold)
            Text("Scan a shared Wi-Fi QR or create one for a network you manage.", color = Muted, style = MaterialTheme.typography.bodySmall)
        }
        item {
            Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.QrCodeScanner, contentDescription = null, tint = Navy)
                        Spacer(Modifier.width(8.dp))
                        Text("Scan a Wi-Fi QR", color = Navy, fontWeight = FontWeight.Bold)
                    }
                    Button(onClick = onScanQr, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                        Icon(Icons.Filled.QrCodeScanner, contentDescription = null)
                        Spacer(Modifier.width(7.dp))
                        Text("Open QR scanner")
                    }
                    scannedQr?.let { qr ->
                        Divider()
                        Text("Decoded network", color = Navy, fontWeight = FontWeight.Bold)
                        Text("Name: ${qr.ssid}")
                        Text("Security: ${qr.security}")
                        Text("Password: ${if (qr.password.isBlank()) "Not included in QR" else "Included (hidden for privacy)"}")
                        Button(
                            onClick = { onConnectScanned(qr) },
                            modifier = Modifier.fillMaxWidth(),
                            enabled = qr.ssid.isNotBlank(),
                            shape = RoundedCornerShape(12.dp)
                        ) { Text("Request connection with Android") }
                    }
                }
            }
        }
        item {
            Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.QrCode2, contentDescription = null, tint = Navy)
                        Spacer(Modifier.width(8.dp))
                        Text("Create your Wi-Fi QR", color = Navy, fontWeight = FontWeight.Bold)
                    }
                    OutlinedTextField(networkName, onNetworkNameChange, modifier = Modifier.fillMaxWidth(), label = { Text("Wi-Fi name (SSID)") }, singleLine = true)
                    OutlinedTextField(password, onPasswordChange, modifier = Modifier.fillMaxWidth(), label = { Text("Wi-Fi password (optional for open networks)") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
                    Button(onClick = onGenerate, modifier = Modifier.fillMaxWidth(), enabled = networkName.isNotBlank(), shape = RoundedCornerShape(12.dp)) {
                        Icon(Icons.Filled.QrCode, contentDescription = null)
                        Spacer(Modifier.width(7.dp))
                        Text("Generate QR code")
                    }
                    generatedQr?.let { bitmap ->
                        Image(bitmap.asImageBitmap(), contentDescription = "Generated Wi-Fi QR code", modifier = Modifier.fillMaxWidth().height(230.dp).padding(8.dp))
                        Text("Anyone who scans this code may be able to join your network. Share it carefully.", color = Muted, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        item {
            Text("A QR code reveals only the details encoded inside it. NetCon cannot recover passwords from nearby networks.", color = Muted, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun EmptyState(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    description: String,
    action: (() -> Unit)? = null
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(
            Modifier.fillMaxWidth().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            Box(Modifier.size(58.dp).clip(CircleShape).background(PaleBlue), contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = null, tint = Navy, modifier = Modifier.size(28.dp))
            }
            Text(title, color = Navy, fontWeight = FontWeight.Bold)
            Text(description, color = Muted, style = MaterialTheme.typography.bodySmall)
            action?.let {
                Button(onClick = it, shape = RoundedCornerShape(12.dp)) { Text("Start scanning") }
            }
        }
    }
}
